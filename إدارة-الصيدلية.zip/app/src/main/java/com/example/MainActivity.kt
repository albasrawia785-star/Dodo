package com.example

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat
import androidx.lifecycle.ViewModelProvider
import com.example.data.local.database.AppDatabase
import com.example.data.repository.PharmacyRepository
import com.example.data.work.ExpiryCheckWorker
import com.example.ui.screens.PharmacyApp
import com.example.ui.theme.MyApplicationTheme
import com.example.ui.viewmodel.PharmacyViewModel
import com.example.ui.viewmodel.PharmacyViewModelFactory
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.SupervisorJob

class MainActivity : ComponentActivity() {

    private val applicationScope = CoroutineScope(SupervisorJob())

    // Permissions requesting launcher
    private val requestPermissionsLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { permissions ->
        val cameraGranted = permissions[Manifest.permission.CAMERA] ?: false
        var bluetoothGranted = true
        
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            val scanGranted = permissions[Manifest.permission.BLUETOOTH_SCAN] ?: false
            val connectGranted = permissions[Manifest.permission.BLUETOOTH_CONNECT] ?: false
            bluetoothGranted = scanGranted && connectGranted
        }

        if (!cameraGranted) {
            Toast.makeText(this, "ملاحظة: مطلوب إذن الكاميرا لتفعيل مسح الباركود.", Toast.LENGTH_LONG).show()
        }
        if (!bluetoothGranted) {
            Toast.makeText(this, "ملاحظة: مطلوب إذن البلوتوث لتشغيل الطباعة الحرارية للفواتير.", Toast.LENGTH_LONG).show()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        // 1. Initialize DB, Repo & ViewModel
        val database = AppDatabase.getDatabase(this, applicationScope)
        val repository = PharmacyRepository(
            companyDao = database.companyDao(),
            medicineDao = database.medicineDao(),
            invoiceDao = database.invoiceDao()
        )
        val viewModelFactory = PharmacyViewModelFactory(application, repository)
        val viewModel = ViewModelProvider(this, viewModelFactory)[PharmacyViewModel::class.java]

        // 2. Request System Permissions (Bluetooth & Camera) dynamically
        checkAndRequestPermissions()

        // 3. Enqueue Daily background work for expiry/low-stock notifications
        ExpiryCheckWorker.enqueueDailyCheck(this)

        // 4. Render main UI with RTL Arabic layout
        setContent {
            MyApplicationTheme {
                PharmacyApp(viewModel = viewModel)
            }
        }
    }

    private fun checkAndRequestPermissions() {
        val permissions = mutableListOf<String>()
        
        // Camera permission for scanner
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
            permissions.add(Manifest.permission.CAMERA)
        }

        // Bluetooth permissions for printer (Android 12+)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.BLUETOOTH_SCAN) != PackageManager.PERMISSION_GRANTED) {
                permissions.add(Manifest.permission.BLUETOOTH_SCAN)
            }
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED) {
                permissions.add(Manifest.permission.BLUETOOTH_CONNECT)
            }
        }

        if (permissions.isNotEmpty()) {
            requestPermissionsLauncher.launch(permissions.toTypedArray())
        }
    }
}
