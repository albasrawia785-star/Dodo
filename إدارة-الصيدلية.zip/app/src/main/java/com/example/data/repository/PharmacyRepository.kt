package com.example.data.repository

import com.example.data.local.dao.CompanyDao
import com.example.data.local.dao.InvoiceDao
import com.example.data.local.dao.MedicineDao
import com.example.data.local.entities.Company
import com.example.data.local.entities.Invoice
import com.example.data.local.entities.InvoiceItem
import com.example.data.local.entities.Medicine
import kotlinx.coroutines.flow.Flow

class PharmacyRepository(
    private val companyDao: CompanyDao,
    private val medicineDao: MedicineDao,
    private val invoiceDao: InvoiceDao
) {
    // 1. Company Operations
    val allCompanies: Flow<List<Company>> = companyDao.getAllCompanies()

    suspend fun getCompanyById(id: Long): Company? = companyDao.getCompanyById(id)

    suspend fun insertCompany(company: Company): Long = companyDao.insertCompany(company)

    suspend fun updateCompany(company: Company) = companyDao.updateCompany(company)

    suspend fun deleteCompany(company: Company) = companyDao.deleteCompany(company)

    // 2. Medicine Operations
    val allMedicines: Flow<List<Medicine>> = medicineDao.getAllMedicines()

    val lowStockMedicines: Flow<List<Medicine>> = medicineDao.getLowStockMedicines()

    fun getExpiringSoonMedicines(currentTime: Long): Flow<List<Medicine>> =
        medicineDao.getExpiringSoonMedicines(currentTime)

    fun searchMedicines(query: String): Flow<List<Medicine>> =
        medicineDao.searchMedicines(query)

    suspend fun getMedicineById(id: Long): Medicine? = medicineDao.getMedicineById(id)

    suspend fun getMedicineByBarcode(barcode: String): Medicine? =
        medicineDao.getMedicineByBarcode(barcode)

    suspend fun insertMedicine(medicine: Medicine): Long = medicineDao.insertMedicine(medicine)

    suspend fun updateMedicine(medicine: Medicine) = medicineDao.updateMedicine(medicine)

    suspend fun deleteMedicine(medicine: Medicine) = medicineDao.deleteMedicine(medicine)

    suspend fun reduceStock(medicineId: Long, quantity: Int) =
        medicineDao.reduceStock(medicineId, quantity)

    suspend fun addStock(medicineId: Long, quantity: Int) =
        medicineDao.addStock(medicineId, quantity)

    // 3. Invoice Operations
    val allInvoices: Flow<List<Invoice>> = invoiceDao.getAllInvoices()

    suspend fun getInvoiceById(invoiceId: Long): Invoice? = invoiceDao.getInvoiceById(invoiceId)

    fun getInvoiceItemsForInvoice(invoiceId: Long): Flow<List<InvoiceItem>> =
        invoiceDao.getInvoiceItemsForInvoice(invoiceId)

    suspend fun getInvoiceItemsForInvoiceSync(invoiceId: Long): List<InvoiceItem> =
        invoiceDao.getInvoiceItemsForInvoiceSync(invoiceId)

    suspend fun createInvoiceWithItems(invoice: Invoice, items: List<InvoiceItem>): Long {
        return invoiceDao.createInvoiceWithItems(invoice, items)
    }
}
