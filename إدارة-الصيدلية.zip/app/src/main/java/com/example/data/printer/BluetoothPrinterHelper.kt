package com.example.data.printer

import android.annotation.SuppressLint
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothSocket
import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Typeface
import android.text.Layout
import android.text.StaticLayout
import android.text.TextPaint
import android.util.Log
import com.example.data.local.entities.Invoice
import com.example.data.local.entities.InvoiceItem
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.OutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID

object BluetoothPrinterHelper {
    private const val TAG = "BluetoothPrinterHelper"
    
    // Standard Serial Port Profile (SPP) UUID
    private val SPP_UUID = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB")

    data class PrinterDevice(val name: String, val address: String)

    /**
     * Get list of paired Bluetooth devices
     */
    @SuppressLint("MissingPermission")
    fun getPairedPrinters(context: Context): List<PrinterDevice> {
        val bluetoothAdapter: BluetoothAdapter? = BluetoothAdapter.getDefaultAdapter()
        if (bluetoothAdapter == null || !bluetoothAdapter.isEnabled) {
            return emptyList()
        }
        
        return bluetoothAdapter.bondedDevices.map { device ->
            PrinterDevice(device.name ?: "Unknown Device", device.address)
        }
    }

    /**
     * Save the MAC address of the default printer in SharedPreferences
     */
    fun saveDefaultPrinterMac(context: Context, macAddress: String) {
        val prefs = context.getSharedPreferences("printer_prefs", Context.MODE_PRIVATE)
        prefs.edit().putString("default_printer_mac", macAddress).apply()
    }

    /**
     * Get the MAC address of the default printer
     */
    fun getDefaultPrinterMac(context: Context): String? {
        val prefs = context.getSharedPreferences("printer_prefs", Context.MODE_PRIVATE)
        return prefs.getString("default_printer_mac", null)
    }

    /**
     * Print invoice on the specified or default Bluetooth printer
     */
    @SuppressLint("MissingPermission")
    suspend fun printInvoice(
        context: Context,
        invoice: Invoice,
        items: List<InvoiceItem>,
        printerMac: String? = null
    ): Boolean = withContext(Dispatchers.IO) {
        val macAddress = printerMac ?: getDefaultPrinterMac(context)
        if (macAddress.isNullOrEmpty()) {
            Log.e(TAG, "No printer MAC address provided and no default printer set.")
            return@withContext false
        }

        val bluetoothAdapter = BluetoothAdapter.getDefaultAdapter()
        if (bluetoothAdapter == null || !bluetoothAdapter.isEnabled) {
            Log.e(TAG, "Bluetooth is disabled or not available.")
            return@withContext false
        }

        var socket: BluetoothSocket? = null
        var outputStream: OutputStream? = null

        try {
            val device = bluetoothAdapter.getRemoteDevice(macAddress)
            socket = device.createRfcommSocketToServiceRecord(SPP_UUID)
            socket.connect()
            outputStream = socket.outputStream

            // 1. Generate Receipt Bitmap (width = 384 pixels, which is standard for 58mm printers)
            val receiptBitmap = generateReceiptBitmap(context, invoice, items, width = 384)

            // 2. Convert Bitmap to ESC/POS bytes
            val escPosBytes = convertBitmapToEscPosBytes(receiptBitmap)

            // 3. Send print commands
            // Initialize printer: ESC @ (1B 40)
            outputStream.write(byteArrayOf(0x1B, 0x40))
            
            // Print the image
            outputStream.write(escPosBytes)

            // Feed paper and cut (or just feed a few lines)
            // Feed 3 lines: LF (0A), LF (0A), LF (0A)
            outputStream.write(byteArrayOf(0x0A, 0x0A, 0x0A))
            
            // Optional: Cut paper command (GS V 66 0): 1D 56 42 00
            outputStream.write(byteArrayOf(0x1D, 0x56, 0x42, 0x00))

            outputStream.flush()
            true
        } catch (e: Exception) {
            Log.e(TAG, "Error printing invoice", e)
            false
        } finally {
            try {
                outputStream?.close()
                socket?.close()
            } catch (e: Exception) {
                // ignore
            }
        }
    }

    /**
     * Generate a monochrome bitmap of the invoice styled beautifully in Arabic (RTL)
     */
    private fun generateReceiptBitmap(
        context: Context,
        invoice: Invoice,
        items: List<InvoiceItem>,
        width: Int
    ): Bitmap {
        // Measure content to dynamically size height
        // Paint setup
        val textPaint = TextPaint().apply {
            color = Color.BLACK
            isAntiAlias = false // Crisp rendering for thermal printing
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.NORMAL)
        }

        // We will layout everything onto a canvas.
        // Let's first calculate estimated height of the receipt
        val rowHeight = 35
        var currentY = 0f
        
        // Header
        val headerHeight = 150
        // Items (header + each item)
        val itemsHeight = (items.size + 1) * rowHeight
        // Footer and totals
        val footerHeight = 220
        
        val totalHeight = headerHeight + itemsHeight + footerHeight
        
        val bitmap = Bitmap.createBitmap(width, totalHeight, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bitmap)
        canvas.drawColor(Color.WHITE) // Background must be white

        val paint = Paint().apply {
            color = Color.BLACK
            strokeWidth = 2f
            style = Paint.Style.FILL
        }

        // Draw Helper Functions
        fun drawCenteredText(text: String, size: Float, y: Float, isBold: Boolean = false) {
            paint.textSize = size
            paint.typeface = if (isBold) Typeface.create(Typeface.DEFAULT, Typeface.BOLD) else Typeface.create(Typeface.DEFAULT, Typeface.NORMAL)
            val textWidth = paint.measureText(text)
            val x = (width - textWidth) / 2
            canvas.drawText(text, x, y, paint)
        }

        fun drawRtlTextLine(rightText: String, leftText: String, size: Float, y: Float, isBold: Boolean = false) {
            paint.textSize = size
            paint.typeface = if (isBold) Typeface.create(Typeface.DEFAULT, Typeface.BOLD) else Typeface.create(Typeface.DEFAULT, Typeface.NORMAL)
            
            // Draw Right-aligned text (Arabic text start)
            val rightMargin = 10f
            val rightX = width - rightMargin - paint.measureText(rightText)
            canvas.drawText(rightText, rightX, y, paint)
            
            // Draw Left-aligned text (Price, count, etc)
            val leftMargin = 10f
            canvas.drawText(leftText, leftMargin, y, paint)
        }

        fun drawDashedLine(y: Float) {
            paint.strokeWidth = 1.5f
            paint.style = Paint.Style.STROKE
            paint.pathEffect = null // solid or dashed
            // We can draw a string of dashes for high compatibility
            val dashStr = "------------------------------------------"
            paint.textSize = 20f
            val dashWidth = paint.measureText(dashStr)
            canvas.drawText(dashStr, (width - dashWidth)/2, y, paint)
            paint.style = Paint.Style.FILL
        }

        // 1. Draw Title
        currentY = 40f
        drawCenteredText("صيدلية الشفاء الذكية", 28f, currentY, isBold = true)
        
        currentY += 35f
        drawCenteredText("هاتف: 07701234567", 20f, currentY)
        
        currentY += 35f
        val sdf = SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.US)
        val formattedDate = sdf.format(Date(invoice.timestamp))
        drawCenteredText("فاتورة مبيعات: ${invoice.invoiceNumber}", 20f, currentY, isBold = true)
        
        currentY += 30f
        drawCenteredText("التاريخ: $formattedDate", 18f, currentY)

        currentY += 20f
        drawDashedLine(currentY)

        // 2. Draw Table Headers (RTL oriented columns)
        // Item Name (Right) | Qty (Middle Right) | Price (Middle Left) | Total (Left)
        currentY += 30f
        paint.textSize = 18f
        paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        
        canvas.drawText("المادة", width - 130f, currentY, paint)
        canvas.drawText("الكمية", width - 210f, currentY, paint)
        canvas.drawText("السعر", width - 300f, currentY, paint)
        canvas.drawText("الإجمالي", 10f, currentY, paint)

        currentY += 15f
        drawDashedLine(currentY)

        // 3. Draw Items
        paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.NORMAL)
        paint.textSize = 16f
        
        for (item in items) {
            currentY += 35f
            
            // Name (might be long, truncate to fit)
            var name = item.medicineName
            if (name.length > 14) {
                name = name.substring(0, 12) + ".."
            }
            canvas.drawText(name, width - 140f, currentY, paint)
            
            // Quantity
            canvas.drawText(item.quantity.toString(), width - 200f, currentY, paint)
            
            // Unit Price (formatted in IQD thousands e.g. 3.5k or fully)
            val priceStr = formatIqdCompat(item.unitPrice)
            canvas.drawText(priceStr, width - 290f, currentY, paint)
            
            // Subtotal
            val subtotalStr = formatIqdCompat(item.subtotal)
            canvas.drawText(subtotalStr, 10f, currentY, paint)
        }

        currentY += 20f
        drawDashedLine(currentY)

        // 4. Totals Block
        currentY += 35f
        drawRtlTextLine("الإجمالي الفرعي:", formatIqd(invoice.totalAmount), 18f, currentY)
        
        if (invoice.discountAmount > 0) {
            currentY += 35f
            drawRtlTextLine("الخصم الممنوح:", "- " + formatIqd(invoice.discountAmount), 18f, currentY)
        }
        
        if (invoice.taxAmount > 0) {
            currentY += 35f
            drawRtlTextLine("الضريبة:", "+ " + formatIqd(invoice.taxAmount), 18f, currentY)
        }

        currentY += 35f
        drawRtlTextLine("المجموع النهائي:", formatIqd(invoice.finalAmount), 22f, currentY, isBold = true)
        
        currentY += 35f
        drawRtlTextLine("المدفوع:", formatIqd(invoice.paidAmount), 18f, currentY)
        
        currentY += 35f
        drawRtlTextLine("المتبقي للعميل:", formatIqd(invoice.changeAmount), 18f, currentY)

        currentY += 25f
        drawDashedLine(currentY)

        // 5. Footer Message
        currentY += 40f
        drawCenteredText("شكراً لزيارتكم وثقتكم بنا!", 20f, currentY, isBold = true)
        
        currentY += 30f
        drawCenteredText("الأدوية المبيعة لا ترد ولا تستبدل", 16f, currentY)
        
        currentY += 25f
        drawCenteredText("إلا بوجود الفاتورة خلال ٢٤ ساعة", 16f, currentY)

        return bitmap
    }

    private fun formatIqd(value: Double): String {
        return String.format(Locale.US, "%,.0f د.ع", value)
    }

    private fun formatIqdCompat(value: Double): String {
        // Shorter format to fit narrow receipts
        if (value >= 1000) {
            return String.format(Locale.US, "%,.0f", value)
        }
        return String.format(Locale.US, "%.0f", value)
    }

    /**
     * Convert monochrome ARGB bitmap to ESC/POS standard raster image format (GS v 0)
     */
    private fun convertBitmapToEscPosBytes(bitmap: Bitmap): ByteArray {
        val width = bitmap.width
        val height = bitmap.height
        
        // Calculate number of horizontal bytes (each bit is 1 pixel)
        val xBytes = (width + 7) / 8
        val totalBytes = xBytes * height
        
        // ESC/POS Command: GS v 0 m xL xH yL yH data
        // GS = 29 (0x1D)
        // v = 118 (0x76)
        // 0 = 48 (0x30)
        // m = 0 (normal size)
        val headerBytes = byteArrayOf(
            0x1D, 0x76, 0x30, 0x00,
            (xBytes % 256).toByte(), (xBytes / 256).toByte(),
            (height % 256).toByte(), (height / 256).toByte()
        )
        
        val imgData = ByteArray(totalBytes)
        var dataIdx = 0

        for (y in 0 until height) {
            var tempByte = 0
            for (x in 0 until xBytes * 8) {
                val bitPos = 7 - (x % 8)
                if (x < width) {
                    val pixel = bitmap.getPixel(x, y)
                    // Extract luminance. If pixel is dark enough, mark as black (1), else white (0)
                    val r = Color.red(pixel)
                    val g = Color.green(pixel)
                    val b = Color.blue(pixel)
                    val luminance = (0.299 * r + 0.587 * g + 0.114 * b)
                    
                    if (luminance < 160) { // Black pixel threshold
                        tempByte = tempByte or (1 shl bitPos)
                    }
                }
                
                if (bitPos == 0) {
                    imgData[dataIdx++] = tempByte.toByte()
                    tempByte = 0
                }
            }
        }
        
        return headerBytes + imgData
    }
}
