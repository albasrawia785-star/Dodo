package com.example.data.backup

import android.content.Context
import android.util.Log
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream

object DatabaseBackupHelper {
    private const val TAG = "DatabaseBackupHelper"
    private const val DB_NAME = "pharmacy_database.db"

    /**
     * Backup active SQLite database file to app cache directory for sharing
     */
    fun backupDatabase(context: Context): File? {
        val dbFile = context.getDatabasePath(DB_NAME)
        if (!dbFile.exists()) {
            Log.e(TAG, "Database file does not exist")
            return null
        }

        try {
            val backupDir = File(context.cacheDir, "backups")
            if (!backupDir.exists()) backupDir.mkdirs()

            val backupFile = File(backupDir, "pharmacy_backup.db")
            if (backupFile.exists()) backupFile.delete()

            FileInputStream(dbFile).use { input ->
                FileOutputStream(backupFile).use { output ->
                    input.copyTo(output)
                }
            }
            return backupFile
        } catch (e: Exception) {
            Log.e(TAG, "Backup database failed", e)
            return null
        }
    }

    /**
     * Restore database from backup file
     */
    fun restoreDatabase(context: Context, backupFile: File): Boolean {
        val dbFile = context.getDatabasePath(DB_NAME)
        if (!backupFile.exists()) {
            Log.e(TAG, "Backup file does not exist")
            return false
        }

        try {
            if (dbFile.exists()) {
                dbFile.delete()
            }
            
            // Delete accompanying temporary WAL and SHM files to prevent corruption/conflicts
            val walFile = File(dbFile.path + "-wal")
            val shmFile = File(dbFile.path + "-shm")
            if (walFile.exists()) walFile.delete()
            if (shmFile.exists()) shmFile.delete()

            if (dbFile.parentFile?.exists() == false) {
                dbFile.parentFile?.mkdirs()
            }

            FileInputStream(backupFile).use { input ->
                FileOutputStream(dbFile).use { output ->
                    input.copyTo(output)
                }
            }
            return true
        } catch (e: Exception) {
            Log.e(TAG, "Restore database failed", e)
            return false
        }
    }
}
