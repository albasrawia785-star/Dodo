package com.example.data.work

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.work.CoroutineWorker
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import com.example.MainActivity
import com.example.data.local.database.AppDatabase
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.withContext
import java.util.concurrent.TimeUnit

class ExpiryCheckWorker(
    context: Context,
    workerParams: WorkerParameters
) : CoroutineWorker(context, workerParams) {

    companion object {
        private const val CHANNEL_ID = "pharmacy_alerts_channel"
        private const val NOTIFICATION_ID = 2026
        
        /**
         * Enqueue daily periodic check
         */
        fun enqueueDailyCheck(context: Context) {
            val request = PeriodicWorkRequestBuilder<ExpiryCheckWorker>(24, TimeUnit.HOURS)
                .addTag("DailyPharmacyCheck")
                .build()
                
            WorkManager.getInstance(context).enqueueUniquePeriodicWork(
                "DailyPharmacyCheckWork",
                androidx.work.ExistingPeriodicWorkPolicy.KEEP,
                request
            )
        }
    }

    override suspend fun doWork(): Result = withContext(Dispatchers.IO) {
        try {
            // Instantiate Database (Scope doesn't need to be long-lived here since worker exits)
            val db = AppDatabase.getDatabase(applicationContext, this)
            
            val lowStockList = db.medicineDao().getLowStockMedicines().first()
            val expiringList = db.medicineDao().getExpiringSoonMedicines(System.currentTimeMillis()).first()
            
            val lowStockCount = lowStockList.size
            val expiringCount = expiringList.size

            if (lowStockCount > 0 || expiringCount > 0) {
                showAlertNotification(lowStockCount, expiringCount)
            }
            Result.success()
        } catch (e: Exception) {
            Result.failure()
        }
    }

    private fun showAlertNotification(lowStockCount: Int, expiringCount: Int) {
        val context = applicationContext
        val notificationManager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

        // Create Channel (Android 8.0+)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "تنبيهات الصيدلية",
                NotificationManager.IMPORTANCE_DEFAULT
            ).apply {
                description = "تنبيهات انتهاء صلاحية الأدوية ونقص الكميات بالمخزن"
            }
            notificationManager.createNotificationChannel(channel)
        }

        // Action when notification clicked (Open MainActivity)
        val intent = Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
        }
        val pendingIntent = PendingIntent.getActivity(
            context,
            0,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        // Notification Text Construction
        val title = "تنبيه مخزون الصيدلية ⚠️"
        val message = StringBuilder()
        if (lowStockCount > 0) {
            message.append("هناك $lowStockCount أدوية كميتها منخفضة بالمخزن. ")
        }
        if (expiringCount > 0) {
            message.append("هناك $expiringCount أدوية تنتهي صلاحيتها خلال ٣ أشهر.")
        }

        val notification = NotificationCompat.Builder(context, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.stat_notify_chat) // default system icon, reliable
            .setContentTitle(title)
            .setContentText(message.toString())
            .setStyle(NotificationCompat.BigTextStyle().bigText(message.toString()))
            .setPriority(NotificationCompat.PRIORITY_DEFAULT)
            .setContentIntent(pendingIntent)
            .setAutoCancel(true)
            .build()

        notificationManager.notify(NOTIFICATION_ID, notification)
    }
}
