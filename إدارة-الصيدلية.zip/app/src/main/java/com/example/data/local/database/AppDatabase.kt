package com.example.data.local.database

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.sqlite.db.SupportSQLiteDatabase
import com.example.data.local.dao.CompanyDao
import com.example.data.local.dao.InvoiceDao
import com.example.data.local.dao.MedicineDao
import com.example.data.local.entities.Company
import com.example.data.local.entities.Invoice
import com.example.data.local.entities.InvoiceItem
import com.example.data.local.entities.Medicine
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Database(
    entities = [
        Company::class,
        Medicine::class,
        Invoice::class,
        InvoiceItem::class
    ],
    version = 1,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {

    abstract fun companyDao(): CompanyDao
    abstract fun medicineDao(): MedicineDao
    abstract fun invoiceDao(): InvoiceDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getDatabase(context: Context, scope: CoroutineScope): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "pharmacy_database.db"
                )
                .addCallback(AppDatabaseCallback(scope))
                .build()
                INSTANCE = instance
                instance
            }
        }

        private fun formatDate(timestamp: Long): String {
            val sdf = SimpleDateFormat("dd/MM/yyyy", Locale.US)
            return sdf.format(Date(timestamp))
        }

        private class AppDatabaseCallback(
            private val scope: CoroutineScope
        ) : RoomDatabase.Callback() {
            override fun onCreate(db: SupportSQLiteDatabase) {
                super.onCreate(db)
                INSTANCE?.let { database ->
                    scope.launch(Dispatchers.IO) {
                        seedData(database)
                    }
                }
            }

            private suspend fun seedData(db: AppDatabase) {
                val companyDao = db.companyDao()
                val medicineDao = db.medicineDao()

                // 1. Seed Companies
                val company1Id = companyDao.insertCompany(
                    Company(
                        name = "شركة الرافدين للأدوية والمستلزمات",
                        phone = "07701234567",
                        address = "العراق، بغداد، شارع السعدون"
                    )
                )
                val company2Id = companyDao.insertCompany(
                    Company(
                        name = "شركة دجلة الطبية المحدودة",
                        phone = "07809876543",
                        address = "العراق، أربيل، منطقة عينكاوة"
                    )
                )

                // 2. Seed Medicines relative to now for reliable alert states
                val now = System.currentTimeMillis()
                val oneDay = 24 * 60 * 60 * 1000L

                // Med 1: Normal panadol
                val exp1 = now + 250 * oneDay
                medicineDao.insertMedicine(
                    Medicine(
                        tradeName = "بندول كولد اند فلو",
                        scientificName = "Paracetamol / Phenylephrine",
                        barcode = "5012345678901",
                        purchasePrice = 2500.0,
                        salePrice = 3500.0,
                        stockQuantity = 45,
                        minStockLimit = 10,
                        expiryDate = formatDate(exp1),
                        expiryTimestamp = exp1,
                        companyId = company1Id
                    )
                )

                // Med 2: Amoxicillin - Low stock and Expiring soon (45 days)
                val exp2 = now + 40 * oneDay
                medicineDao.insertMedicine(
                    Medicine(
                        tradeName = "أموكسيسيلين 500 ملغ",
                        scientificName = "Amoxicillin Trihydrate",
                        barcode = "6221122334455",
                        purchasePrice = 1200.0,
                        salePrice = 2000.0,
                        stockQuantity = 3, // Low stock (min is 10)
                        minStockLimit = 10,
                        expiryDate = formatDate(exp2),
                        expiryTimestamp = exp2,
                        companyId = company2Id
                    )
                )

                // Med 3: Omeprazole - Expiring soon (60 days)
                val exp3 = now + 60 * oneDay
                medicineDao.insertMedicine(
                    Medicine(
                        tradeName = "أوميبرازول 20 ملغ",
                        scientificName = "Omeprazole",
                        barcode = "6229876543210",
                        purchasePrice = 1800.0,
                        salePrice = 2750.0,
                        stockQuantity = 20,
                        minStockLimit = 5,
                        expiryDate = formatDate(exp3),
                        expiryTimestamp = exp3,
                        companyId = company1Id
                    )
                )

                // Med 4: Brufen 400 - Low Stock only (2 items left)
                val exp4 = now + 400 * oneDay
                medicineDao.insertMedicine(
                    Medicine(
                        tradeName = "بروفين 400 ملغ",
                        scientificName = "Ibuprofen",
                        barcode = "5011122334455",
                        purchasePrice = 1500.0,
                        salePrice = 2500.0,
                        stockQuantity = 2, // Low stock
                        minStockLimit = 8,
                        expiryDate = formatDate(exp4),
                        expiryTimestamp = exp4,
                        companyId = company2Id
                    )
                )

                // Med 5: Vitamin C - High stock, normal expiry
                val exp5 = now + 500 * oneDay
                medicineDao.insertMedicine(
                    Medicine(
                        tradeName = "فيتامين سي الفوار 1000 ملغ",
                        scientificName = "Ascorbic Acid",
                        barcode = "6225566778899",
                        purchasePrice = 3000.0,
                        salePrice = 4500.0,
                        stockQuantity = 120,
                        minStockLimit = 15,
                        expiryDate = formatDate(exp5),
                        expiryTimestamp = exp5,
                        companyId = company1Id
                    )
                )
            }
        }
    }
}
