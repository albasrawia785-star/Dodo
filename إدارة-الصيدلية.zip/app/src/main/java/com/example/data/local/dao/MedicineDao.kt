package com.example.data.local.dao

import androidx.room.*
import com.example.data.local.entities.Medicine
import kotlinx.coroutines.flow.Flow

@Dao
interface MedicineDao {
    @Query("SELECT * FROM medicines ORDER BY tradeName ASC")
    fun getAllMedicines(): Flow<List<Medicine>>

    @Query("SELECT * FROM medicines WHERE id = :id")
    suspend fun getMedicineById(id: Long): Medicine?

    @Query("SELECT * FROM medicines WHERE barcode = :barcode LIMIT 1")
    suspend fun getMedicineByBarcode(barcode: String): Medicine?

    @Query("SELECT * FROM medicines WHERE stockQuantity <= minStockLimit ORDER BY stockQuantity ASC")
    fun getLowStockMedicines(): Flow<List<Medicine>>

    @Query("SELECT * FROM medicines WHERE expiryTimestamp <= :currentTime + 7776000000 ORDER BY expiryTimestamp ASC")
    fun getExpiringSoonMedicines(currentTime: Long): Flow<List<Medicine>>

    @Query("SELECT * FROM medicines WHERE tradeName LIKE '%' || :query || '%' OR scientificName LIKE '%' || :query || '%' OR barcode LIKE '%' || :query || '%'")
    fun searchMedicines(query: String): Flow<List<Medicine>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertMedicine(medicine: Medicine): Long

    @Update
    suspend fun updateMedicine(medicine: Medicine)

    @Delete
    suspend fun deleteMedicine(medicine: Medicine)

    @Query("UPDATE medicines SET stockQuantity = stockQuantity - :quantity WHERE id = :medicineId")
    suspend fun reduceStock(medicineId: Long, quantity: Int)

    @Query("UPDATE medicines SET stockQuantity = stockQuantity + :quantity WHERE id = :medicineId")
    suspend fun addStock(medicineId: Long, quantity: Int)
}
