package com.example.data.exporter

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Typeface
import android.graphics.pdf.PdfDocument
import android.os.Environment
import android.util.Log
import com.example.data.local.entities.Invoice
import com.example.data.local.entities.Medicine
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object ReportExporter {
    private const val TAG = "ReportExporter"

    /**
     * Export medicine inventory to a styled PDF document using Native PdfDocument
     */
    fun exportInventoryToPdf(context: Context, medicines: List<Medicine>): File? {
        val pdfDocument = PdfDocument()
        
        // A4 Page size: 595 x 842 points (72 points/inch)
        val pageWidth = 595
        val pageHeight = 842
        
        val paint = Paint()
        val textPaint = Paint()
        
        // Setup Page Info
        val pageInfo = PdfDocument.PageInfo.Builder(pageWidth, pageHeight, 1).create()
        val page = pdfDocument.startPage(pageInfo)
        val canvas: Canvas = page.canvas

        try {
            // Background color
            canvas.drawColor(Color.WHITE)

            // 1. Draw Title Header
            paint.color = Color.parseColor("#0D47A1") // Deep Medical Blue
            paint.style = Paint.Style.FILL
            canvas.drawRect(0f, 0f, pageWidth.toFloat(), 90f, paint)

            textPaint.color = Color.WHITE
            textPaint.textSize = 22f
            textPaint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            val titleText = "تقرير جرد المخزون - صيدلية الشفاء"
            val titleWidth = textPaint.measureText(titleText)
            canvas.drawText(titleText, (pageWidth - titleWidth) / 2, 52f, textPaint)

            // Current date
            textPaint.textSize = 11f
            textPaint.color = Color.WHITE
            textPaint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.NORMAL)
            val sdf = SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.US)
            val currentDateText = "تاريخ التصدير: " + sdf.format(Date())
            val dateWidth = textPaint.measureText(currentDateText)
            canvas.drawText(currentDateText, (pageWidth - dateWidth) / 2, 75f, textPaint)

            // 2. Draw Table Header
            val tableY = 130f
            paint.color = Color.parseColor("#E3F2FD") // Light blue background
            canvas.drawRect(20f, tableY - 20f, (pageWidth - 20).toFloat(), tableY + 15f, paint)

            textPaint.color = Color.parseColor("#0D47A1")
            textPaint.textSize = 11f
            textPaint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)

            // Table Columns positions (right to left for Arabic)
            val colExpiry = 30f      // Leftmost (Expiry)
            val colStock = 140f
            val colSalePrice = 220f
            val colPurchasePrice = 300f
            val colSciName = 380f
            val colTradeName = 480f   // Rightmost (Name)

            canvas.drawText("الاسم التجاري", colTradeName, tableY, textPaint)
            canvas.drawText("الاسم العلمي", colSciName, tableY, textPaint)
            canvas.drawText("سعر الشراء", colPurchasePrice, tableY, textPaint)
            canvas.drawText("سعر البيع", colSalePrice, tableY, textPaint)
            canvas.drawText("المخزون", colStock, tableY, textPaint)
            canvas.drawText("تاريخ الصلاحية", colExpiry, tableY, textPaint)

            // 3. Draw Items
            var currentY = tableY + 35f
            textPaint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.NORMAL)
            textPaint.color = Color.BLACK
            
            // Draw grid line paint
            val linePaint = Paint().apply {
                color = Color.parseColor("#E0E0E0")
                strokeWidth = 1f
            }

            for ((index, med) in medicines.withIndex()) {
                // If we reach near the bottom, we stop or we'd need a multi-page PDF. 
                // For a robust single page inventory preview, let's support up to ~20 items, or clip.
                if (currentY > pageHeight - 50) {
                    break
                }

                // Zebra striping
                if (index % 2 == 1) {
                    paint.color = Color.parseColor("#F5F5F5")
                    canvas.drawRect(20f, currentY - 20f, (pageWidth - 20).toFloat(), currentY + 10f, paint)
                }

                // Warn color for low stock
                val stockText = med.stockQuantity.toString()
                if (med.stockQuantity <= med.minStockLimit) {
                    textPaint.color = Color.RED
                    textPaint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
                } else {
                    textPaint.color = Color.BLACK
                    textPaint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.NORMAL)
                }

                // Draw Text
                // Truncate strings if too long
                val tradeNameStr = if (med.tradeName.length > 15) med.tradeName.substring(0, 13) + ".." else med.tradeName
                val sciNameStr = if (med.scientificName.length > 15) med.scientificName.substring(0, 13) + ".." else med.scientificName

                canvas.drawText(tradeNameStr, colTradeName, currentY, textPaint)
                canvas.drawText(sciNameStr, colSciName, currentY, textPaint)
                
                // Normal text paint for numbers
                textPaint.color = Color.BLACK
                textPaint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.NORMAL)
                
                canvas.drawText(formatIqd(med.purchasePrice), colPurchasePrice, currentY, textPaint)
                canvas.drawText(formatIqd(med.salePrice), colSalePrice, currentY, textPaint)
                
                // Low stock stock warning print
                if (med.stockQuantity <= med.minStockLimit) {
                    textPaint.color = Color.RED
                }
                canvas.drawText(stockText, colStock, currentY, textPaint)
                textPaint.color = Color.BLACK

                // Color expiry orange/red if near
                val daysToExpiry = (med.expiryTimestamp - System.currentTimeMillis()) / (24 * 60 * 60 * 1000)
                if (daysToExpiry < 90) {
                    textPaint.color = Color.parseColor("#E65100") // Deep Orange
                    textPaint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
                }
                canvas.drawText(med.expiryDate, colExpiry, currentY, textPaint)
                textPaint.color = Color.BLACK
                textPaint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.NORMAL)

                // Grid line
                canvas.drawLine(20f, currentY + 10f, (pageWidth - 20).toFloat(), currentY + 10f, linePaint)
                currentY += 30f
            }

            // 4. Footer
            textPaint.textSize = 9f
            textPaint.color = Color.GRAY
            val footerText = "نظام إدارة الصيدلية الذكي - العمل دون اتصال بالإنترنت"
            canvas.drawText(footerText, 20f, (pageHeight - 25).toFloat(), textPaint)
            
            val countText = "إجمالي المواد: ${medicines.size}"
            canvas.drawText(countText, (pageWidth - textPaint.measureText(countText) - 20f), (pageHeight - 25).toFloat(), textPaint)

            pdfDocument.finishPage(page)

            // Save file
            val exportsDir = File(context.cacheDir, "exports")
            if (!exportsDir.exists()) exportsDir.mkdirs()
            
            val file = File(exportsDir, "inventory_report_${System.currentTimeMillis()}.pdf")
            pdfDocument.writeTo(FileOutputStream(file))
            return file
        } catch (e: Exception) {
            Log.e(TAG, "Error writing PDF", e)
            return null
        } finally {
            pdfDocument.close()
        }
    }

    /**
     * Export all invoices to a clean CSV text file
     */
    fun exportInvoicesToCsv(context: Context, invoices: List<Invoice>): File? {
        val csvBuilder = StringBuilder()
        
        // CSV Header (Arabic columns with UTF-8 BOM)
        csvBuilder.append('\ufeff') // Excel Arabic RTL encoding helper
        csvBuilder.append("رقم الفاتورة,التاريخ والوقت,المبلغ الإجمالي,الخصم,الضريبة,المبلغ الصافي,المدفوع,المتبقي للعميل\n")

        val sdf = SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.US)

        for (invoice in invoices) {
            val dateStr = sdf.format(Date(invoice.timestamp))
            csvBuilder.append("${invoice.invoiceNumber},")
            csvBuilder.append("$dateStr,")
            csvBuilder.append("${invoice.totalAmount},")
            csvBuilder.append("${invoice.discountAmount},")
            csvBuilder.append("${invoice.taxAmount},")
            csvBuilder.append("${invoice.finalAmount},")
            csvBuilder.append("${invoice.paidAmount},")
            csvBuilder.append("${invoice.changeAmount}\n")
        }

        try {
            val exportsDir = File(context.cacheDir, "exports")
            if (!exportsDir.exists()) exportsDir.mkdirs()

            val file = File(exportsDir, "sales_report_${System.currentTimeMillis()}.csv")
            val outputStream = FileOutputStream(file)
            outputStream.write(csvBuilder.toString().toByteArray(Charsets.UTF_8))
            outputStream.close()
            return file
        } catch (e: Exception) {
            Log.e(TAG, "Error writing CSV", e)
            return null
        }
    }

    private fun formatIqd(value: Double): String {
        return String.format(Locale.US, "%,.0f", value)
    }
}
